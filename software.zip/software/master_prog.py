from Tkinter import *
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec



master = Tk()

def var_states():
   print("Lorenz System: %d,\nRossler System: %d" % (var1.get(), var2.get()))

def run_prog():
	if var1.get()==0 and var2.get()==0 and var3.get()==0 and var4.get()==0 and var5.get()==0:
		print "Error1: Check one of the listed systems"
	elif var1.get()==1 and var2.get()==0 and var3.get()==0 and var4.get()==0 and var5.get()==0:
		execfile("systems/lorenz.py")
	elif var1.get()==0 and var2.get()==1 and var3.get()==0 and var4.get()==0 and var5.get()==0:
		execfile("systems/rossler.py")
	elif var1.get()==0 and var2.get()==0 and var3.get()==1 and var4.get()==0 and var5.get()==0:
		execfile("systems/mg.py")
	elif var1.get()==0 and var2.get()==0 and var3.get()==0 and var4.get()==1 and var5.get()==0:
		execfile("systems/ddex_slider_grid.py")
	elif var1.get()==0 and var2.get()==0 and var3.get()==0 and var4.get()==0 and var5.get()==1:
		execfile("systems/logistic.py")
	else:
		print "Error2: Check olny one of the systems"

#------------------------------------------
Label(master,text="Differential Equation solver!",bg="Green",fg="white",font = "Helvetica 12 bold italic").grid(row=0,column=1)

Label(master, text="Select System:",bg="white",fg="blue",font = "Helvetica 12 bold italic").grid(row=1, sticky=W)
Label(master, text="-> Chaotic ODEs:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=2, sticky=W)

Label(master,text="x'=sigma*(y-x), y'=r*(1-z)*x-y, z'=-b*z+x*y,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=3,column=1)
var1 = IntVar()
Checkbutton(master, text="Lorenz System:", variable=var1).grid(row=3, sticky=W)

Label(master,text="x'=-y-z, y'=x+a*y, z'=b+z*(x-c),\t      ",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=4,column=1)
var2 = IntVar()
Checkbutton(master, text="Rossler System:", variable=var2).grid(row=4, sticky=W)

Label(master, text="-> Chaotic DDEs:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=5, sticky=W)

Label(master,text="x'=-a*x(t)+b*[x(t-tau)/(1-x(t-tau)^n)]\t     ,",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=6,column=1)
var3 = IntVar()
Checkbutton(master, text="Mackey-Glass System:", variable=var3).grid(row=6, sticky=W)

Label(master,text="x'=-a*x(t)+b*[-n*x(t-tau)+m*tanh(l*x(t-tau))],",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=7,column=1)
var4 = IntVar()
Checkbutton(master, text="Equivalent MG System:", variable=var4).grid(row=7, sticky=W)

Label(master, text="-> Chaotic Maps:",bg="white",fg="red",font = "Helvetica 12 bold italic").grid(row=8, sticky=W)
Label(master,text="x_(n+1)=r*x_n*(1-x_n),",bg="white",fg="black",font = "Helvetica 10 italic").grid(row=9,column=1)
var5 = IntVar()
Checkbutton(master, text="Logistic Map:", variable=var5).grid(row=9, sticky=W)


Button(master, text='Quit', command=master.quit,bg="Red",fg="White").grid(row=11, column=0, sticky=W, pady=3)
Button(master, text='Run', command=run_prog,bg="Yellow",fg="Blue").grid(row=11, column=4, sticky=W, pady=4)
mainloop()


